import React from "react";

function CreateLink(props) {
  return <div>CreateLink</div>;
}

export default CreateLink;
