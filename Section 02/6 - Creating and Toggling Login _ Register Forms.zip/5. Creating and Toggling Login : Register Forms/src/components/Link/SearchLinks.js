import React from "react";

function SearchLinks() {
  return <div>SearchLinks</div>;
}

export default SearchLinks;
