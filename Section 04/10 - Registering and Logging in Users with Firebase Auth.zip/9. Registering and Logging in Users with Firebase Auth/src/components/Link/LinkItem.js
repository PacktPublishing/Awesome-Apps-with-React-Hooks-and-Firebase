import React from "react";

function LinkItem() {
  return <div>LinkItem</div>;
}

export default LinkItem;
