import React from "react";

function LinkList(props) {
  return <div>LinkList</div>;
}

export default LinkList;
