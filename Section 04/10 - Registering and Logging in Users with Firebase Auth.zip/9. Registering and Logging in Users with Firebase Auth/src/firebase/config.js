var firebaseConfig = {
  INSERT: "YOUR_FIREBASE_CONFIG_HERE"
};

export default firebaseConfig;
