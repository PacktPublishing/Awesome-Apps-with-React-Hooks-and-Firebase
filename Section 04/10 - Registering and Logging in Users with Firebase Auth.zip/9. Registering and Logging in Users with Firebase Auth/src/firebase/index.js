import firebase from "./firebase";

export default firebase;
