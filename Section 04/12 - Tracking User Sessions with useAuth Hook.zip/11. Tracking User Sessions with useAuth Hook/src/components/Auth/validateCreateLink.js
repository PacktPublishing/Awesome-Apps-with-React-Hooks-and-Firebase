export default function validateCreateLink(values) {}
