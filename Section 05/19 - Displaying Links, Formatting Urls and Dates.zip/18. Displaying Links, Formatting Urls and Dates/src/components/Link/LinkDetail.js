import React from "react";

function LinkDetail(props) {
  return <div>LinkDetail</div>;
}

export default LinkDetail;
